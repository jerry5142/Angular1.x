//globals
var format;
var gantt;
var taskNames = [];
var tasks = [];
//set the initial axis start and end datetimes
var axisStartDate = new Date(moment("2018-01-29T00:00:00-06:00").format("YYYY-MM-DD HH:mm")); 
var axisEndDate = new Date(moment("2018-01-30T23:59:59-06:00").format("YYYY-MM-DD HH:mm")); 
var axisMode = {  //static: fixed axis, dynamic: axis fits the data
      "static": "fixed",
      "dynamic": "fit"
   };
var timeDomainString = {   
      "hour1": "1hr",
      "hour3": "3hr",
      "hour6": "6hr",
      "hour24": "24hr",      
      "day1": "1day",
      "week1": "1week",
   };

var taskStatus = {
    "SUCCEEDED" : "bar",
    "FAILED" : "bar-failed",
    "RUNNING" : "bar-running",
    "KILLED" : "bar-killed"
};

//get the task data
d3.json("data/jobs.json", function(data) {
   tasks = data.data;
   tasks.forEach(function(task){
        task.startDate = new Date(task.startDate); 
        task.endDate = new Date(task.endDate);   	  
      taskNames.push(task.taskName);
   });
   main();
});

//begin execution
function main(){ 
   //sort the task data by endDate
   tasks.sort(function(a, b) {
       return a.endDate - b.endDate;
   });
   //sort the task data by startDate   
   tasks.sort(function(a, b) {
       return a.startDate - b.startDate;
   });

   format = "%H:%M";
//   timeDomainString = "1day";

   gantt = d3.gantt().taskTypes(taskNames).taskStatus(taskStatus).tickFormat(format).height(450).width(800);

//   gantt.timeDomainMode("fixed");
   gantt.timeDomainMode(axisMode.static);
   changeTimeDomain(timeDomainString.hour24);

   gantt(tasks);
};

function changeTimeDomain(timeDomainString) {
    this.timeDomainString = timeDomainString;
    switch (timeDomainString) {
    case "1hr":
   format = "%H:%M:%S";
   gantt.timeDomain([ d3.time.hour.offset(getEndDate(), -1), getEndDate() ]);
   break;
    case "3hr":
   format = "%H:%M";
   gantt.timeDomain([ d3.time.hour.offset(getEndDate(), -3), getEndDate() ]);
   break;

    case "6hr":
   format = "%H:%M";
   gantt.timeDomain([ d3.time.hour.offset(getEndDate(), -6), getEndDate() ]);
   break;

    case "1day":
   format = "%H:%M";
   gantt.timeDomain([ d3.time.day.offset(getEndDate(), -1), getEndDate() ]);
   break;

    case "1week":
   format = "%a %H:%M";
   gantt.timeDomain([ d3.time.day.offset(getEndDate(), -7), getEndDate() ]);
   break;
    case "24hr":
   format = "%H:%M";
   gantt.timeDomain([ axisStartDate, axisEndDate ]);
   break;
    default:
   format = "%H:%M"

    }
    gantt.tickFormat(format);
    gantt.redraw(tasks);
}

function getEndDate() {
    var lastEndDate = Date.now();
    if (tasks.length > 0) {
   lastEndDate = tasks[tasks.length - 1].endDate;
    }

    return lastEndDate;
}

function addTask() {

    var lastEndDate = getEndDate();
    var taskStatusKeys = Object.keys(taskStatus);
    var taskStatusName = taskStatusKeys[Math.floor(Math.random() * taskStatusKeys.length)];
    var taskName = taskNames[Math.floor(Math.random() * taskNames.length)];

    tasks.push({
   "startDate" : d3.time.hour.offset(lastEndDate, Math.ceil(1 * Math.random())),
   "endDate" : d3.time.hour.offset(lastEndDate, (Math.ceil(Math.random() * 3)) + 1),
   "taskName" : taskName,
   "status" : taskStatusName
    });

    changeTimeDomain(timeDomainString);
    gantt.redraw(tasks);
};

function removeTask() {
    tasks.pop();
    changeTimeDomain(timeDomainString);
    gantt.redraw(tasks);
};
